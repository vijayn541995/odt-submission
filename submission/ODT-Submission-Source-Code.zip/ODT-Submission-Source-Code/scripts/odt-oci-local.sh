#!/usr/bin/env bash

export OCI_CLI_PROFILE="CS4I_AI_LAB"
export OCI_CLI_PATH="/opt/homebrew/bin/oci"
export OCI_REGION="us-ashburn-1"

export ODT_PROMPT_PROVIDER="oci"
export OCI_COMPARTMENT_OCID="ocid1.compartment.oc1..aaaaaaaa4nedctdt7xy3tbik4p6uv4yodznguqqu3sygnoskwnayd23zx6ma"
export OCI_GENAI_MODEL_ID="openai.gpt-4o-mini"

export ODT_OCI_TIMEOUT_MS="120000"
export ODT_OCI_MAX_TOKENS="1200"
export ODT_OCI_TEMPERATURE="0.2"
export ODT_OCI_TOP_P="0.8"
export SUPPRESS_LABEL_WARNING="True"

echo "ODT OCI local environment loaded."
echo "OCI_CLI_PROFILE=$OCI_CLI_PROFILE"
echo "OCI_REGION=$OCI_REGION"
echo "ODT_PROMPT_PROVIDER=$ODT_PROMPT_PROVIDER"
echo "OCI_COMPARTMENT_OCID=${OCI_COMPARTMENT_OCID:0:24}..."
echo "OCI_GENAI_MODEL_ID=$OCI_GENAI_MODEL_ID"
